<?php
//title gets handeled via template part teaser
?>