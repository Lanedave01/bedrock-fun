<?php
if(!lambda_is_plugin_active('revslider/revslider.php')) {
	require_once ( get_template_directory()  . '/revslider/revslider.php' );
}	
?>