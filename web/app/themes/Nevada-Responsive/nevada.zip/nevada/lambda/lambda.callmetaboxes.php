<?php

/*
 * call all needed MetaBoxes * Passion Theme 1.0
 * lambda framework v 1.0
 * by www.unitedthemes.com
 * since lambda framework v 1.0
 */
 
include_once ( 'metaboxes/lambda.meta.spec.php' );

?>